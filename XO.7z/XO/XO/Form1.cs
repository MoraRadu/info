﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XO
{
    public partial class frmXO : Form
    {
        Color[] culori = { Color.Aqua, Color.Azure, Color.Beige, Color.Bisque, Color.Black, Color.BlanchedAlmond, Color.Blue, Color.BlueViolet, Color.Brown, Color.BurlyWood, Color.CadetBlue, Color.Chartreuse, Color.Chocolate, Color.Coral, Color.CornflowerBlue, Color.Cornsilk, Color.Crimson, Color.Cyan, Color.DarkBlue, Color.DarkCyan, Color.DarkGoldenrod, Color.DarkGray, Color.DarkGreen, Color.DarkKhaki, Color.YellowGreen };
        int click = 0, nrculori = 0, victoriix = 0, victorii0 = 0;
        private string corect()
        {
            if (label1.Text == label2.Text && label2.Text == label3.Text)
            {
                return label1.Text;
            }
            if (label4.Text == label5.Text && label5.Text == label6.Text)
            {
                return label4.Text;
            }
            if (label7.Text == label8.Text && label8.Text == label9.Text)
            {
                return label7.Text;
            }
            if (label1.Text == label4.Text && label4.Text == label7.Text)
            {
                return label1.Text;
            }
            if (label2.Text == label5.Text && label5.Text == label8.Text)
            {
                return label2.Text;
            }
            if (label3.Text == label6.Text && label6.Text == label9.Text)
            {
                return label3.Text;
            }
            if (label1.Text == label5.Text && label5.Text == label9.Text)
            {
                return label1.Text;
            }
            if (label3.Text == label5.Text && label5.Text == label7.Text)
            {
                return label3.Text;
            }
            return "";
        }
        public frmXO()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Label label = (sender as Label);
            if (label.Text != "")
            {
                return;
            }
            click++;
            if (click % 2 == 0)
            {
                label.Text = "O";
            }
            else
            {
                label.Text = "X";
            }
            if (corect() == "X")
            {
                MessageBox.Show("Victorie X");
                victoriix++;
                label1.Text = "";
                label2.Text = "";
                label3.Text = "";
                label4.Text = "";
                label5.Text = "";
                label6.Text = "";
                label7.Text = "";
                label9.Text = "";
                label8.Text = "";
                label16.Text = victoriix.ToString();
                click = 0;
            }
            if (corect() == "O")
            {
                MessageBox.Show("Victorie 0");
                victorii0++;
                label1.Text = "";
                label2.Text = "";
                label3.Text = "";
                label4.Text = "";
                label5.Text = "";
                label6.Text = "";
                label7.Text = "";
                label9.Text = "";
                label8.Text = "";
                label17.Text = victorii0.ToString();
                click = 0;
            }
            if (corect() != "X" && corect() != "O" && click == 9)
            {
                MessageBox.Show("Remiza");
                label1.Text = "";
                label2.Text = "";
                label3.Text = "";
                label4.Text = "";
                label5.Text = "";
                label6.Text = "";
                label7.Text = "";
                label9.Text = "";
                label8.Text = "";
                click = 0;
            }
        }

        private void frmXO_KeyPress(object sender, KeyPressEventArgs e)
        {
            //MessageBox.Show(e.KeyChar.ToString());

            click++;
            if (e.KeyChar.ToString() == "1")
            {
                if (label7.Text != "")
                {
                    click--;
                    return;
                }
                if (click % 2 == 0)
                {
                    label7.Text = "O";
                }
                if (click % 2 == 1)
                {
                    label7.Text = "X";
                }
            }
            if (e.KeyChar.ToString() == "2")
            {
                if (label8.Text != "")
                {
                    click--;
                    return;
                }
                if (click % 2 == 0)
                {
                    label8.Text = "O";
                }
                if (click % 2 == 1)
                {
                    label8.Text = "X";
                }
            }
            if (e.KeyChar.ToString() == "3")
            {
                if (label9.Text != "")
                {
                    click--;
                    return;
                }
                if (click % 2 == 0)
                {
                    label9.Text = "O";
                }
                if (click % 2 == 1)
                {
                    label9.Text = "X";
                }
            }
            if (e.KeyChar.ToString() == "4")
            {
                if (label4.Text != "")
                {
                    click--;
                    return;
                }
                if (click % 2 == 0)
                {
                    label4.Text = "O";
                }
                if (click % 2 == 1)
                {
                    label4.Text = "X";
                }
            }
            if (e.KeyChar.ToString() == "5")
            {
                if (label5.Text != "")
                {
                    click--;
                    return;
                }
                if (click % 2 == 0)
                {
                    label5.Text = "O";
                }
                if (click % 2 == 1)
                {
                    label5.Text = "X";
                }
            }
            if (e.KeyChar.ToString() == "6")
            {
                if (label6.Text != "")
                {
                    click--;
                    return;
                }
                if (click % 2 == 0)
                {
                    label6.Text = "O";
                }
                if (click % 2 == 1)
                {
                    label6.Text = "X";
                }
            }
            if (e.KeyChar.ToString() == "7")
            {
                if (label1.Text != "")
                {
                    click--;
                    return;
                }
                if (click % 2 == 0)
                {
                    label1.Text = "O";
                }
                if (click % 2 == 1)
                {
                    label1.Text = "X";
                }
            }
            if (e.KeyChar.ToString() == "8")
            {
                if (label2.Text != "")
                {
                    click--;
                    return;
                }
                if (click % 2 == 0)
                {
                    label2.Text = "O";
                }
                if (click % 2 == 1)
                {
                    label2.Text = "X";
                }
            }
            if (e.KeyChar.ToString() == "9")
            {
                if (label3.Text != "")
                {
                    click--;
                    return;
                }
                if (click % 2 == 0)
                {
                    label3.Text = "O";
                }
                if (click % 2 == 1)
                {
                    label3.Text = "X";
                }
            }
            if (corect() == "X")
            {
                MessageBox.Show("Victorie X");
                victoriix++;
                label1.Text = "";
                label2.Text = "";
                label3.Text = "";
                label4.Text = "";
                label5.Text = "";
                label6.Text = "";
                label7.Text = "";
                label9.Text = "";
                label8.Text = "";
                label16.Text = victoriix.ToString();
                click = 0;
            }
            if (corect() == "O")
            {
                MessageBox.Show("Victorie 0");
                victorii0++;
                label1.Text = "";
                label2.Text = "";
                label3.Text = "";
                label4.Text = "";
                label5.Text = "";
                label6.Text = "";
                label7.Text = "";
                label9.Text = "";
                label8.Text = "";
                label17.Text = victorii0.ToString();
                click = 0;
            }
            if (corect() != "X" && corect() != "O" && click == 9)
            {
                MessageBox.Show("Remiza");
                label1.Text = "";
                label2.Text = "";
                label3.Text = "";
                label4.Text = "";
                label5.Text = "";
                label6.Text = "";
                label7.Text = "";
                label9.Text = "";
                label8.Text = "";
                click = 0;
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
            label8.Text = "";
            label9.Text = "";
            click = 0;
        }


        private void label13_Click(object sender, EventArgs e)
        {
            nrculori++;
            this.BackColor = culori[nrculori];
        }
    }
}
